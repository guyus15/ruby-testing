module ChessPieces
    class Generic
        attr_reader :name, :symbol, :team

        def initialize(team)
            @team = team
            @name = "Generic"
            @symbol = ""
        end
    end
    class King < Generic
        def initialize(team)
            super
            team == "white" ? @symbol = "♔" : @symbol = "♚"
        end
    end
    class Queen < Generic
        def initialize(team)
            super
            team == "white" ? @symbol = "♕" : @symbol = "♛"
        end
    end
    class Bishop < Generic
        def initialize(team)
            super
            team == "white" ? @symbol = "♗" : @symbol = "♝"
        end
    end
    class Knight < Generic
        def initialize(team)
            super
            team == "white" ? @symbol = "♘" : @symbol = "♞"
        end
    end
    class Rook < Generic
        def initialize(team)
            super
            team == "white" ? @symbol = "♖" : @symbol = "♜"
        end
    end
    class Pawn < Generic
        def initialize(team)
            super
            team == "white" ? @symbol = "♙" : @symbol = "♟"
        end
    end

end