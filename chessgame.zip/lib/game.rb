require_relative 'board'
require_relative 'chess_pieces'

class Game
    include ChessPieces

    def initialize
        @game_board = Board.new
    end
    
    def setup_board
        @game_board.update_tile(0,0, "X")
        @game_board.debug_display
    end

    def create_piece(piece_name, team_name)
        case piece_name
        when "king"      
            team_name == "white" ? (return King.new("white")) : (return King.new("black"))
        when "queen"
            team_name == "white" ? (return Queen.new("white")) : (return Queen.new("black"))
        when "bishop"
            team_name == "white" ? (return Bishop.new("white")) : (return Bishop.new("black"))
        when "knight"
            team_name == "white" ? (return Knight.new("white")) : (return Knight.new("black"))
        when "rook"
            team_name == "white" ? (return Rook.new("white")) : (return Rook.new("black"))
        when "pawn"
            team_name == "white" ? (return Pawn.new("white")) : (return Pawn.new("black"))
        else
            team_name == "white" ? (return Pawn.new("white")) : (return Pawn.new("black"))
        end
    end
end