
class Board
  attr_reader :board

  def initialize
    @board = Array.new(8, Array.new(8, ' '))
  end

  def debug_display
    p board
  end

  def display_board
    board.each_with_index do |row, r_index|
      if r_index == 0
        row.each_with_index do |_column, c_index|
          c_index == 0 ? (print '+---+') : (print '---+')
        end
      end
      print "\n"
      row.each_with_index do |column, c_index|
        c_index == 0 ? (print "| #{column} |") : (print " #{column} |")
      end
      print "\n"
      row.each_with_index do |_column, c_index|
        c_index == 0 ? (print '+---+') : (print '---+')
      end
    end
  end

  def update_tile(x_coord, y_coord, symbol)
    puts "X COORD: #{x_coord}\nY COORD: #{y_coord}"
    board[y_coord][x_coord] = symbol
  end
end
