require_relative 'lib/game'

game = Game.new

game.setup_board

